﻿using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models;
using System.Text;
using System.Text.Json;

namespace RaceDay.MVC.Controllers
{
    public class EnrolmentController : Controller
    {
        private readonly IConfiguration _configuration;

        public EnrolmentController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View("~/Views/Create.cshtml");
        }

        [HttpPost]
        public async Task<IActionResult> Create(EnrolmentDto model)
        {
            var apiUrl = _configuration["ApiSettings:BaseUrl"] + "Enrolment";

            using var client = new HttpClient();

            var json = JsonSerializer.Serialize(model);

            var content = new StringContent(
                json,
                Encoding.UTF8,
                "application/json");

            var response = await client.PostAsync(apiUrl, content);

            if (response.IsSuccessStatusCode)
            {
                ViewBag.SuccessMessage = "Enrolment successful!";
            }
            else
            {
                ViewBag.ErrorMessage = "Enrolment failed.";
            }

            return View("~/Views/Create.cshtml");
        }
    }
}