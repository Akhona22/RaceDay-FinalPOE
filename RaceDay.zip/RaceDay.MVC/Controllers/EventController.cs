﻿using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models;
using System.Text;
using System.Text.Json;

namespace RaceDay.MVC.Controllers
{
    public class EventController : Controller
    {
        private readonly IConfiguration _configuration;

        public EventController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<IActionResult> Index()
        {
            var apiUrl = _configuration["ApiSettings:BaseUrl"] + "Event";

            using var client = new HttpClient();

            var response = await client.GetAsync(apiUrl);

            if (!response.IsSuccessStatusCode)
            {
                return View(new List<EventDto>());
            }

            var json = await response.Content.ReadAsStringAsync();

            var events = JsonSerializer.Deserialize<List<EventDto>>
            (
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                }
            );

            return View(events);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(EventDto model)
        {
            var apiUrl = _configuration["ApiSettings:BaseUrl"] + "Event";

            using var client = new HttpClient();

            var json = JsonSerializer.Serialize(model);

            var content = new StringContent(
                json,
                Encoding.UTF8,
                "application/json");

            var response = await client.PostAsync(apiUrl, content);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            ViewBag.ErrorMessage = "Event creation failed.";

            return View(model);
        }
    }
}
