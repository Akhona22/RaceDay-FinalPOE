﻿using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models;
using System.Text;
using System.Text.Json;

namespace RaceDay.MVC.Controllers
{
    public class CategoryController : Controller
    {
        private readonly IConfiguration _configuration;

        public CategoryController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<IActionResult> Index()
        {
            var apiUrl = _configuration["ApiSettings:BaseUrl"] + "Category";

            using var client = new HttpClient();

            var response = await client.GetAsync(apiUrl);

            if (!response.IsSuccessStatusCode)
            {
                return View(new List<CategoryDto>());
            }

            var json = await response.Content.ReadAsStringAsync();

            var categories = JsonSerializer.Deserialize<List<CategoryDto>>
            (
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                }
            );

            return View(categories);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(CategoryDto model)
        {
            var apiUrl = _configuration["ApiSettings:BaseUrl"] + "Category";

            using var client = new HttpClient();

            var json = JsonSerializer.Serialize(model);

            var content = new StringContent(
                json,
                Encoding.UTF8,
                "application/json");

            var response = await client.PostAsync(apiUrl, content);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            ViewBag.ErrorMessage = "Category creation failed.";

            return View(model);
        }
    }
}
